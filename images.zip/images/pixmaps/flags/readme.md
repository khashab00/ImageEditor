# Translators

If translating Photoflare into a new language copy the relevant image file from /all_flags to the /flags directory.
